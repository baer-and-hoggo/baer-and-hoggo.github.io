Original transparent PNG brand artwork from baerandhoggo.com.
Please preserve proportions and colors. These are brand assets, not gameplay screenshots.
Credit: Farmion / Baer & Hoggo Games.
