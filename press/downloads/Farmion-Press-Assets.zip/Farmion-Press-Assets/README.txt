FARMION / PRESS ASSETS
September 2026

Includes 21 original in-game screenshots, original transparent brand artwork, a five-page PDF, and editable plain-text press copy.

Credit: Farmion / Baer & Hoggo Games.
Contact: baerandhoggo@gmail.com
Steam: https://store.steampowered.com/app/2426390/Farmion/

All screenshots show a game in development. Logo and chicken/mascot artwork are separate brand assets. No AI-generated gameplay images have been added.
Sources and SHA-256 fingerprints are in asset-manifest.json.
