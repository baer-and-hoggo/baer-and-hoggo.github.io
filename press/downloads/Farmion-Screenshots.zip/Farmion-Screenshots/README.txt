Original Steam gallery images, 1920 pixels wide. Heights vary; original aspect ratios are preserved. In development.
Credit: Farmion / Baer & Hoggo Games.
See asset-manifest.json in the full press assets for source URLs and captions.
